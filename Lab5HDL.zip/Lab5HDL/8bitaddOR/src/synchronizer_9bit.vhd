-------------------------------------------------------------------------------
-- nick
-- synchronizer 8 bit
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;      

entity synchronizer_9bit is 
  port (
    clk               : in std_logic;
    reset             : in std_logic;
    async_in          : in std_logic_vector(8 downto 0);
    sync_out          : out std_logic_vector(11 downto 0)
  );
end synchronizer_9bit;

architecture beh of synchronizer_9bit is
-- signal declarations
signal flop1     : std_logic_vector(8 downto 0);
signal flop2     : std_logic_vector(8 downto 0);

begin 
double_flop :process(reset,clk,async_in)
  begin
    if reset = '1' then
      flop1 <= "000000000";   
      flop2 <= "000000000";	
    elsif rising_edge(clk) then
      flop1 <= async_in;
      flop2 <= flop1;
    end if;
end process;

sync_out <= "000" & flop2;
end beh; 